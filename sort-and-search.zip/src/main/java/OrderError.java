
public class OrderError extends IllegalArgumentException{
	
	private static final long serialVersionUID = 1L;

	public OrderError() {}

	public OrderError(String s) {
		super(s);
	}

	public OrderError(Throwable cause) {
		super(cause);
	}

	public OrderError(String message, Throwable cause) {
		super(message, cause);
	}

}
